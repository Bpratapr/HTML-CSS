<?php require("part3.php");?>
<div class="sink">
<p>Our site provides online appointment to top doctors in INDIA.
We will Charge Money for appointmet.</p>
</div>
<?php require("part2.php");?>