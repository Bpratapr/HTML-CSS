<html>
<head>
<title>Find Your Doctor</title>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="doc1.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div class="wrapper" >
<div class="header">
<div class="icon">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a href="main.html">Home</a></li>
<li><a class="in" href="doc1.php">Doctors</a></li>
<li><a href="imp.php">Contact</a></li>
<li><a href="about.php">About Us</a></li>

</ul>
</div>
</div>

<div class="content">
<p class="name">Good Doctor</p>
<p class="quote"><span id="q">&ldquo;</span>Good doctors understand responsibility better than privellege
 and practice accountability better than business.<span id="q">&rdquo;</span></p>
</div>
<div class="doctor">
<div class="ins" id="som1">
</div>
<h2>Dr.Swathi</h2>
<h2>M.B.B.S,M.R.C.S,M.P.P.S</h2>
<h2>Eye Specialist</h2>
<h3><a href="sign.php">Sign in for appointment</a></h3>

</div>



<div class="doctor">
<div class="ins" id="som2">
</div>
<h2>Dr.Divya</h2>
<h2>M.B.B.S,M.R.C.S,M.P.P.S</h2>
<h2>Heart Surgeon</h2>
<h3><a href="sign.php">Sign in for appointment</a></h3>

</div>

<div class="doctor">
<div class="ins" id="som3">
</div>
<h2>Dr.Viseswar Rao</h2>
<h2>M.B.B.S,M.P.P.S</h2>
<h2>Cardiologist</h2>
<h3><a href="sign.php">Sign in for appointment</a></h3>

</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>


</div>
</body>
</html>