<html>
<head>
<title>Find Your Doctor</title>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="reg.css" type="text/css" rel="stylesheet" />
<link href="reg1.css" type="text/css" rel="stylesheet" />
<link href="imp.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.nav ul li a.out{
	
color:white;
}
div.regs a:link{
	color:black;
	font-family:sans-serif;
	text-decoration:none;
}
div.regs a:visited{
	color:black;
	font-family:sans-serif;
	text-decoration:none;
}
div.regs a:hover{
	color:green;
	font-family:sans-serif;
	font-size:20px;
}
</style>
</head>
<body>
<div class="wrapper" >
<div class="header">
<div class="icon">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="main.html">Home</a></li>
<li><a class="in" href="doc1.php">Doctors</a></li>
<li><a class="out" href="imp.php">Contact</a></li>
<li><a class="sin" href="/">About Us</a></li>

</ul>
</div>
</div>

<div class="content">
<p class="name">Good Doctor</p>
<p class="quote"><span id="q">&ldquo;</span>Good doctors understand responsibility better than privellege
 and practice accountability better than business.<span id="q">&rdquo;</span></p>
</div>