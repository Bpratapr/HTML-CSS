
<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.content p{
	color:white;
	font-size:30px;
	text-align:center;
	margin-top:100px;
	
}

table{
	width:60%;
	margin:100px auto;
	color:white;
	font-size:18px;
	border:4px solid white;
	border-radius:10px;
}
th{
	text-align:left;
}
td,th{
	border:1px solid white;
	
}

</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="profile.php">Patients</a></li>
<li><a class="in" href="patdoc.php">Questions</a></li>
<li><a class="out" href="#">Notifications</a></li>
<li><a class="sin" href="logout.php">Logout</a></li>

</ul>
</div>
</div>

<div class="content">

<?php
$doctor1="Dr.swathi";


mysql_connect("localhost","root","");
mysql_select_db("doctor");
$select=mysql_query("SELECT * FROM patient WHERE doctor='$doctor1'");
	$ans=$_POST["$username"];

$numrows=mysql_num_rows($select);
while($row=mysql_fetch_assoc($select)){
	$username=$row["username"];
	mysql_query("UPDATE patient SET answer='$ans' WHERE doctor='$doctor1'");
}
?>


</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>
