
<?php
session_start();
$user=$_SESSION["username"];

$document_root=$_SERVER["DOCUMENT_ROOT"];
?>
<?php
$userf=$user.".txt";

file("$document_root/doctor/$userf","r");

?>