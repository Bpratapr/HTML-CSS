<?php
session_start();
@$_SESSION["username"];
?>
<html>
<head>
<title>Find Your Doctor</title>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="doc1.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.looin{
	float:left;
	width:100%;
	color:balck;
	background-color:#efefef;
	height:100px;
	margin-left:0px;
	text-align:center;
	font-size:30px;
	padding-top:40px;
	
}
</style>
</head>
<body>
<div class="wrapper" >
<div class="header">
<div class="icon">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="profile.php">Profile</a></li>
<li><a class="in" href="patdoc.php">Doctors</a></li>
<li><a class="out" href="details.php">Your Details</a></li>
<li><a class="sin" href="logout.php">Logout</a></li>

</ul>
</div>
</div>

<div class="content">
<p class="name">Good Doctor</p>
<p class="quote"><span id="q">&ldquo;</span>Good doctors understand responsibility better than privellege
 and practice accountability better than business.<span id="q">&rdquo;</span></p>
</div>

<?php
if(@$_SESSION["username"])
echo'
<div class="doctor">
<div class="ins" id="som1">
</div>
<h2>Dr.Swathi</h2>
<h2>M.B.B.S,M.R.C.S,M.P.P.S</h2>
<h2>Eye Specialist</h2>
<h3><a href="onlineform.php">Register Online!!!</a></h3>

</div>



<div class="doctor">
<div class="ins" id="som2">
</div>
<h2>Dr.Divya</h2>
<h2>M.B.B.S,M.R.C.S,M.P.P.S</h2>
<h2>Heart Surgeon</h2>
<h3><a href="onlineform1.php">Register Online!!!</a></h3>

</div>

<div class="doctor">
<div class="ins" id="som3">
</div>
<h2>Dr.Viseswar Rao</h2>
<h2>M.B.B.S,M.P.P.S</h2>
<h2>Cardiologist</h2>
<h3><a href="onlineform2.php">Register Online!!!</a></h3>

</div>

';
else{
	echo"<div class='looin'>
	<p>You Must be logged in.</p>
	</div>";
	
}
?>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>


</div>
</body>
</html>