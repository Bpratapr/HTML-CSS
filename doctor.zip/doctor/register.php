<?php
require("part1.php");
?>

<div class="signin">
<fieldset>
<legend>Register Form</legend>
<form action="registernon.php" method="post">
<table>
<tr>
<td>
<label for="name">Username</label>
</td>
<td>
<input id="name" type="text" name="name" maxlength="40" size="20" required="required" placeholder="Enter your name" />
</td>
</tr>

<tr>
<td>
<label for="date">Date Of Birth</label>
</td>
<td>
<input id="date" type="date" name="date"  size="20" required="required" placeholder="Enter your Date Of Birth" />
</td>
</tr>

<tr>
<td>
<label for="email" >Email</label>
</td>
<td>
<input id="email" type="email" name="email" maxlength="200" size="20" required="required" placeholder="Enter your email" />
</td>
</tr>



<tr>
<td>
<label>Gender</label>
</td>
<td>
<input id="male" type="radio" name="gender" value="yes" checked="checked" /><label for="male">Male</label>
<input id="female" type="radio" name="gender" value="no" /><label for="female">Female</label>

</td>
</tr>

<tr>
<td>
<label for="password" >Password</label>
</td>
<td>
<input id="password" type="password" name="password" maxlength="30" size="20" required="required" placeholder="Enter password" />
</td>
</tr>


<tr>
<td>
<label for="password1" >Repeat Password</label>
</td>
<td>
<input id="password1" type="password" name="password1" maxlength="30" size="20" required="required" placeholder="Enter password again" />
</td>
</tr>

<tr id="sub">
<td colspan="2"><input id="submit" type="submit" value="Register" /></td>
</tr>
</table>
</form>
</fieldset>
</div>
<?php
require("part2.php");
?>