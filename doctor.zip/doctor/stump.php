
<?php
require("regi.php");
?>
<?php

$username=$_POST["name"];
$password=$_POST["password1"];
$connect=mysql_connect("localhost","root","")or die("couldnot connect");
mysql_select_db("doctor")or die("couldnot connect");
$query=mysql_query("SELECT * FROM patient WHERE username='$username'");
$numrows=mysql_num_rows($query);
if($numrows!=0)
{
	while($row=mysql_fetch_assoc($query)){
		$dbusername=$row["username"];
		$dbpassword=$row["password"];
		
	}
	
	if($username==$dbusername && $password==$dbpassword){
		session_start();
		$_SESSION['username']=$dbusername;
			
				echo "<div class='regs'>";
						echo "You are logged in.<a href='member.php'>Click here</a> to get into your page.";

echo "</div>";
			
			exit;
			
			
	}else{
		
			echo "<div class='regs'>";
echo "<p>Incorrect Password.<br />Go back and try again.</p>";
echo "</div>";
exit;
	}
}else{
	echo "<div class='regs'>";
echo "<p>User does not exist.<br />Go back and try again.</p>";
echo "</div>";
exit;	
}
?>


<?php
require("part2.php");
?>