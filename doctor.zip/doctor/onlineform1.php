<?php
session_start();
@$_SESSION["username"];
$doctor1="Dr.Divya";
?>
<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.content p{
	color:white;
	font-size:30px;
	text-align:center;
	margin-top:100px;
	
}
div.content h2{
	color:white;
	text-align:center;
}
</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="profile.php">Profile</a></li>
<li><a class="in" href="patdoc.php">Doctors</a></li>
<li><a class="out" href="#">Notifications</a></li>
<li><a class="sin" href="logout.php">Logout</a></li>

</ul>
</div>
</div>

<div class="content">

<?php
if(@$_SESSION["username"]){
		echo "<h2>It will charge Rs.500.</h2>";

	echo "<fieldset>
	<legend>Online Appointment</legend>
	<form action='onlineres1.php' method='post'>
	<table>
	<tr>
	<td>
	<label for='dat'>Date of appointment</label>
	</td>
	<td>
	<input id='dat' type='date' name='dat' required='required' />
	</td>
	</tr>
	
	<tr class='sub'>
	<td colspan='2'><input class='sub' type='submit' value='Register Online'  /></td>
	</tr>
	</table>
	</form>
	
	</filedset>
	
	";
	
	
	
}else{
	
	echo"<p>You must be logged in.</p>";
}
?>

</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>