<?php require("part3.php");?>
<div class="contact">
<fieldset>
<legend>Contact Form</legend>
<form action="esubmit.php" method="post">
<table>
<tr>
<td>
<label for="name">Name</label>
</td>
<td>
<input id="name" type="text" name="name" required="required" maxlength="40" size="20" placeholder="Enter your name" />
</td>
</tr>

<tr>
<td>
<label for="email">Email</label>
</td>
<td>
<input id="email" type="email" name="email" required="required" maxlength="200" size="20" placeholder="Enter your email" />
</td>
</tr>

<tr>
<td>
<label for="comment">Feedback</label>
</td>
<td>
<textarea id="comment" cols="30" rows="5" name="comment" placeholder="Enter your Feedback" required="required"></textarea>
</td>
</tr>
<?php
require("submit.php");
?>
</table>
</form>

</fieldset>
</div>

<?php require("part2.php");?>