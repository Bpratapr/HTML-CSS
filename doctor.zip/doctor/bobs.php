<html>
<head>
<title></title>
<style type="text/css">
div{
float:left;
width:40%;
}
form{
float:left;
width:60%;
}
</style>
</head>
<body>
<form action="bobs1.php" method="post">
<table>
<tr>
<th>Item</th>
<th>Quantity</th>
</tr>

<tr>
<td>Tires</td>
<td><input type="text" name="tireqty" size="3" maxlength="3" /></td>
</tr>
<tr>
<td>Oil</td>
<td><input type="text" name="oilqty" size="3" maxlength="3" /></td>
</tr>

<tr>
<td>Spark Plugs</td>
<td><input type="text" name="sparkqty" size="3" maxlength="3" /></td>
</tr>

<tr>
<td>
Shipping Address
</td>
<td>
<input type="text/css" name="address" maxlength="500" size="30" />
</td>
</tr>

<tr>
<td><input type="submit" value="Submit Order" /></td>
</tr>
</table>
</form>
<div>
<table>
<tr>
<th>Distance</th>
<th>Cost</th>
<?php
$distance=50;
while($distance<=250){
echo "<tr>
<td>".$distance."</td>
<td>".($distance/10)."</td>
</tr>\n";
$distance+=50;
}
?>
</tr>
</table>
</div>
</body>
</html>