
<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.content p{
	color:white;
	font-size:30px;
	text-align:center;
	margin-top:100px;
	
}
</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="profile.php">Profile</a></li>
<li><a class="in" href="patdoc.php">Doctors</a></li>
<li><a class="out" href="details.php">Your Details</a></li>
<li><a class="sin" href="logout.php">Logout</a></li>

</ul>
</div>
</div>

<div class="content">
<?php
session_start();
 @$user=$_SESSION["username"];
$date=$_POST["dat"];
$doctor1="Dr.Visweswar Rao";
$datenow=date("Y-m-d");
if($date<$datenow){
	
	echo "<p>Enter correct date.</p>";
	exit;
}
?>

<?php
if(@$_SESSION["username"]){
	mysql_connect("localhost","root","");
	mysql_select_db("doctor");
	mysql_query("UPDATE patient SET doctor='$doctor1' WHERE username='$user'");
    mysql_query("UPDATE patient SET apdate='$date' WHERE username='$user'");
	$array=array("11am","12am","10am","2pm","1pm","3pm","4pm","5pm","6pm");
	shuffle($array);
echo "<p>Hi $user you got appointment with $doctor1 on $date at $array[0]
<br />You will be charged Rs.500.</p>";
}else{
	
	echo "<p>You must be logged in.</p>";
}
?>

</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>