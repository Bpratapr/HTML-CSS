
<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.content p{
	color:white;
	font-size:30px;
	text-align:center;
	margin-top:100px;
}
</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="profile.php">Profile</a></li>
<li><a class="in" href="patdoc.php">Doctors</a></li>
<li><a class="out" href="#">Notifications</a></li>
<li><a class="sin" href="logout.php">Logout</a></li>

</ul>
</div>
</div>

<div class="content">
<?php
session_start();
 $user=$_SESSION["username"];
 $pro=$_POST["problem"];
 $que=$_POST["question"];

if($user){
	$connect=mysql_connect("localhost","root","");
	mysql_select_db("doctor");
	mysql_query("UPDATE patient SET  problem='$pro' WHERE username='$user'");
		mysql_query("UPDATE patient SET question='$que' WHERE username='$user'");
		echo "<p>Hi $user!!!.You have submitted your details successfully.</p>";


}else
{
	
	echo "<p>You must be logged in.</p>";
}
?>
</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>