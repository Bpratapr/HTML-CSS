

<?php
require("part3.php");
?>

<?php
$name=$_POST["name"];
$date=$_POST["date"];
$email=$_POST["email"];
$password=$_POST["password"];
$password1=$_POST["password1"];
$com=date("Y");
$gender=$_POST["gender"];
$document_root=$_SERVER['DOCUMENT_ROOT'];
$date123=date("H:i jS F Y");
$d=date("Y-m-d");
?>
<?php
$connect=mysql_connect("localhost","root","");
mysql_select_db("doctor");
$namecheck=mysql_query("SELECT username FROM patient WHERE username='$name'");
$count=mysql_num_rows($namecheck);
if($count!=0){
	echo "<div class='regs'>";
echo "<p>Already a user exists with this username.<br />Go back and try again.</p>";
echo "</div>";
exit;
	
}

$emailcheck=mysql_query("SELECT email FROM patient WHERE email='$email'");
$ecount=mysql_num_rows($emailcheck);
if($ecount!=0){
	echo "<div class='regs'>";
echo "<p>A user alredy registered with this email.<br />Go back and try again.</p>";
echo "</div>";
exit;
}
?>



<?php
if(strlen($name)<6){
echo "<div class='regs'>";
echo "<p>Name Should atleast have 6 letters.<br />Go back and try again.</p>";
echo "</div>";
exit;
}


if(strlen($name)>30){
echo "<div class='regs'>";
echo "<p>Name should have less than 31 characters.<br />Go back and try again.</p>";
echo "</div>";
exit;
}

if($date>=$com){
echo "<div class='regs'>";
echo "<p>Please enter correct date of birth.<br />Go back and try again.</p>";
echo "</div>";
exit;
}
if($date<1917){
echo "<div class='regs'>";
echo "<p>Please enter correct date of birth.<br />Go back and try again.</p>";
echo "</div>";
exit;
}
if($date>1999){
echo "<div class='regs'>";
echo "<p>You Cannot Register.<br />
Your are not adult.</p>";
echo "</div>";
exit;
}
if(strlen($password)>30 || strlen($password1)>30){
echo "<div class='regs'>";
echo "<p>Your password should not excede 30 characters.<br />Go back and try again.</p>";
echo "</div>";
exit;
}

if(strlen($password)<8|| strlen($password1)<8){
echo "<div class='regs'>";
echo "<p>Your password should not be less than 8.<br />Go back and try again.</p>";
echo "</div>";
exit;
}
if($password!=$password1){
echo "<div class='regs'>";
echo "<p>Your password and Repeat Password are not matching.<br />Go back and try again.</p>";
echo "</div>";
exit;
}

switch($gender){
case 'yes':
$gender="male";
break;
case 'no':
$gender="female";
break;

}


?>

<!--Code for login system.-->
<?php
$enter=mysql_query("INSERT INTO patient VALUES('','$name','$date','$email','$gender','$password','$d','nothing','nothing','--','--')");
?>

<div class="regs">
<?php
echo "Hi ".$name." you have sucessfully registered your account at ".$date123;
echo "<p><a href='sign.php'>Sign In</a></p>";
?>
</div>

<?php
require("part2.php");
?>

