<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.content p{
	color:white;
	font-size:30px;
	text-align:center;
	margin-top:100px;
	
}

table{
	width:60%;
	margin:100px auto;
	color:white;
	font-size:18px;
	border:4px solid white;
	border-radius:10px;
}
th{
	text-align:left;
}
td,th{
	border:1px solid white;
	padding:9px;
	
}
</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="profile.php">Profile</a></li>
<li><a class="in" href="patdoc.php">Doctors</a></li>
<li><a class="out" href="details.php">Your Details</a></li>
<li><a class="sin" href="logout.php">Logout</a></li>

</ul>
</div>
</div>

<div class="content">

<?php
session_start();
@$user=$_SESSION["username"];
if(@$_SESSION["username"]){
	mysql_connect("localhost","root","");
	mysql_select_db("doctor");
	
	$select=mysql_query("SELECT * FROM patient WHERE username='$user'");
	$numrows=mysql_num_rows($select);
	echo "<table>";
	echo "<tr>
	<th>Username</th>
	<th>Date Of Birth</th>
	<th>Email</th>
		<th>Gender</th>
			<th>Password</th>
	<th>Date of Registeration</th>
	<th>Problem</th>
	<th>Question</th>
	<th>Doctor</th>
	<th>Appointment Date</th>


	</tr>";
	while($row=mysql_fetch_assoc($select)){ 
     $name=$row["username"];	
	 $dob=$row["dob"];
	 $email=$row["email"];
	 $gender=$row["gender"];
	 $password=$row["password"];
	 $regdate=$row["date"];
	 $problem=$row["problem"];
	 $question=$row["question"];
	 $doctor=$row["doctor"];
	 $apdate=$row["apdate"];
	 
	 echo "<tr>
	 <td>$name</td>
	 	 <td>$dob</td>
	 <td>$email</td>
	 <td>$gender</td>
	 <td>$password</td>
	 <td>$regdate</td>
	 <td>$problem</td>
	 <td>$question</td>
	 <td>$doctor</td>
	 <td>$apdate</td>

	 </tr>";
	 
	}
	
	echo "</table>";
	
}else{
	
	echo"<p>You must be logged in.</p>";
}
?>


</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>
