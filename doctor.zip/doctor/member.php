<?php
session_start();
 @$_SESSION['username'];
?>
<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.content p{
	color:white;
	font-size:30px;
	text-align:center;
	margin-top:100px;
	
}
</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="profile.php">Profile</a></li>
<li><a class="in" href="patdoc.php">Doctors</a></li>
<li><a class="out" href="details.php">Your Details</a></li>
<li><a class="sin" href="logout.php">Logout</a></li>

</ul>
</div>
</div>

<div class="content">
<?php

if(@$_SESSION["username"]){
	echo "<div class='profile'>";
	
	echo "<fieldset>";
	echo "<legend>More Details</legend>";
	echo "<form action='pat.php' method='post'>";
echo "<table>";
echo "<tr>";
echo "<td>";
echo "<label fpr='pro'>Problems</label>";

echo "</td>";
echo "<td>";
echo"<input id='pro' type='text'name='problem' required='required' maxlength='100' size='50' />";
echo "</td>";
echo "</tr>";





echo "<tr>";
echo "<td>";
echo "<label fpr='que'>Questions to Doctor</label>";

echo "</td>";
echo "<td>";
echo"<input id='que' type='text'name='question' required='required' maxlength='100' size='50' />";
echo "</td>";
echo "</tr>";

echo "<tr class='sub'>";
echo "<td colspan='2'>";
echo "<input type='submit' class='sub' value='Submit' />";
echo "</td>";
echo "</tr>";
echo "</table>";
echo "</form>";	
	echo "</fieldset>";
	echo "</div>";
	
}else{
	
	echo "<p>You must be logged in.</p>";
}
?>
</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>