
<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.pq{
	width:30%;
	float:left;
	border:4px solid white;
	border-radius:10px;
	padding:10px;
	margin:100px 20px 20px 100px;
	color:white;
}
div.pq p{
	
	font-size:20px;
}

div.content p{
	color:white;
	font-size:30px;
	text-align:center;
	margin-top:100px;
	
}
</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="profile.php">Profile</a></li>
<li><a class="in" href="patdoc.php">Doctors</a></li>
<li><a class="out" href="details.php">Your Details</a></li>
<li><a class="sin" href="logout.php">Logout</a></li>

</ul>
</div>
</div>

<div class="content">

<?php
session_start();
@$user=$_SESSION["username"];
mysql_connect("localhost","root","");
mysql_select_db("doctor");
if($user){
$query=mysql_query("SELECT problem,question FROM patient WHERE username='$user'");
while($row=mysql_fetch_assoc($query)){
	$problem=$row["problem"];
	$question=$row["question"];	
	
}
echo "<div class='pq'>
<h1>Your Problems</h1>
<p>*$problem</p>
</div>";

echo "<div class='pq'>
<h1>Your Questions</h1>
<p>*$question</p>
</div>";

}else
{
	
	echo"<p>You must be logged in.</p>";
}
?>

</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>