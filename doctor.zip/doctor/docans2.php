

<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.content p{
	color:white;
	font-size:30px;
	text-align:center;
	margin-top:100px;
	
}

table{
	width:60%;
	margin:100px auto;
	color:white;
	font-size:18px;
	border:4px solid white;
	border-radius:10px;
}
th{
	text-align:left;
}
td,th{
	border:1px solid white;
	
}

</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="sin" href="visweswar.php">Home</a></li>

<li><a class="on" href="pdetails2.php">Patients</a></li>
<li><a class="in" href="docans2.php">Questions</a></li>

</ul>
</div>
</div>

<div class="content">
<?php
mysql_connect("localhost","root","");
mysql_select_db("doctor");
$doctor1="Dr.Visweswar Rao";

$datnow=date("Y");
$select=mysql_query("SELECT * FROM patient WHERE doctor='$doctor1'");
$numrows=mysql_num_rows($select);
echo "<form>";
echo "<table>";
echo "<tr>
<th>Name</th>
<th>Problem</th>
<th>Question</th>
<th>Doctor</th>

</tr>";
while($row=mysql_fetch_assoc($select)){
	$username=$row["username"];
	$problem=$row["problem"];
	$question=$row["question"];
	

	echo "
	<tr>
	<td>
	$username
	
	</td>
	<td>
	$problem
	</td>
	<td>
	$question
	</td>
	<td>
	$doctor1
	</td>
	
	
	</tr>
	";
	
	
}

echo "

</table>
</form>";
?>

</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>
