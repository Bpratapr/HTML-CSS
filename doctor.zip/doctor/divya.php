
<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.content p{
	color:white;
	font-size:30px;
	text-align:center;
	margin-top:100px;
	
}


div.doctor{
width:30%;
border:4px solid black;
border-radius:10px;

margin:30px auto;
background-image:url("bunk3.jpg");
background-position:center;

}

div.ins{
width:200px;
height:200px;
border:5px solid pink;
margin:10px auto;
border-radius:200px;
}
div#som2{
background-image:url("doc3.jpg");

}



div.doctor h2{
font-size:20px;
text-align:center;
padding:2px;
color:black;

}
</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="sin" href="divya.php">Home</a></li>

<li><a class="on" href="pdetails1.php">Patients</a></li>
<li><a class="in" href="docans1.php">Questions</a></li>

</ul>
</div>
</div>

<div class="content">
<div class="doctor">
<div class="ins" id="som2">
</div>
<h2>Dr.Divya</h2>
<h2>M.B.B.S,M.R.C.S,M.P.P.S</h2>
<h2>Heart Surgeon</h2>

</div>
</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>