<html>
<head>
<title>Find Your Doctor</title>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="sign.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div class="wrapper" >
<div class="header">
<div class="icon">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="main.html">Home</a></li>
<li><a class="in" href="doc1.php">Doctors</a></li>
<li><a class="out" href="imp.php">Contact</a></li>
<li><a class="sin" href="about.php">About Us</a></li>

</ul>
</div>
</div>

<div class="content">
<p class="name">Good Doctor</p>
<p class="quote"><span id="q">&ldquo;</span>Good doctors understand responsibility better than privellege
 and practice accountability better than business.<span id="q">&rdquo;</span></p>
</div>

<div class="signin">
<fieldset>
<legend>Signup Form</legend>
<form action="stump.php" method="post">
<table>
<tr>
<td><label for="name">Username</label></td>
<td><input id="name" type="text" name="name" maxlength="40" size="20" required="required" placeholder="Enter your name" /></td>
</tr>
<tr>
<td><label for="password">Password</label></td>
<td><input id="password" type="password" name="password1" maxlength="20" size="20" required="required" placeholder="Enter your password" /></td>
</tr>

<tr id="sub">
<td colspan="2"><input id="submit" type="submit" value="Sign In" /></td>
</tr>
</table>
</form>
<div class="line">

</div>
<p class="reg"><a id="reg" href="register.php">Register Now!!!</a></p>
</fieldset>

</div>
</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>