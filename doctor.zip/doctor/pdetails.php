
<?php
session_start();
 @$_SESSION['username'];
?>
<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.content p{
	color:white;
	font-size:30px;
	text-align:center;
	margin-top:100px;
	
}

table{
	width:60%;
	margin:100px auto;
	color:white;
	font-size:18px;
	border:4px solid white;
	border-radius:10px;
}
th{
	text-align:left;
}
td,th{
	border:1px solid white;
	
}

</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="sin" href="swathi.php">Home</a></li>

<li><a class="on" href="pdetails.php">Patients</a></li>
<li><a class="in" href="docans.php">Questions</a></li>

</ul>
</div>
</div>

<div class="content">
<?php
mysql_connect("localhost","root","");
mysql_select_db("doctor");
$doctor1="Dr.swathi";
$datnow=date("Y");
$select=mysql_query("SELECT * FROM patient WHERE doctor='$doctor1'");
$numrows=mysql_num_rows($select);
echo "<table>";
echo "<tr>
<th>Name</th>
<th>Gender</th>
<th>Age</th>
<th>Appointment Date</th>
<th>Doctor</th>
</tr>";
while($row=mysql_fetch_assoc($select)){
	$username=$row["username"];
	$gender=$row["gender"];
	$dob=$row["dob"];
	$apdate=$row["apdate"];
	$doctor=$row["doctor"];
		$age=$datnow-$dob;

	echo "
	<tr>
	<td>
	$username
	</td>
	<td>
	$gender
	</td>
	<td>
	$age
	</td>
	<td>
	$apdate
	</td>
	<td>
	$doctor
	</td>
	</tr>
	";
}
echo "</table>";
?>

</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>