<?php
$tireqty=$_POST["tireqty"];
$oilqty=$_POST["oilqty"];
$sparkqty=$_POST["sparkqty"];
$totalqty=0;
$totalamount=0.00;
define("TIREPRICE",100);
define("OILPRICE",10);
define("SPARKPRICE",4);
$documnet_root=$_SERVER["DOCUMENT_ROOT"];
$address=preg_replace('/\t|\R/',' ',$_POST["address"]);

$date=date("H:i jS F Y");
?>
<html>
<head>
<title>Bob's Auto Parts Results</title>
</head>
<body>
<h1>Bob's Auto Parts</h1>
<h2>Order Processed</h2>
<?php echo "<p>Your order processed at ".date("H:i jS F Y")."</p>";
echo "<p>Your order is as follows:</p>";
$totalqty=$tireqty+$oilqty+$sparkqty;
if($totalqty==0){
echo "You havent ordered ant thing.Go back and try again.";
exit();
}else{
echo htmlspecialchars($tireqty)." tires<br />";
echo htmlspecialchars($oilqty)." bottles of oil<br />";
echo htmlspecialchars($sparkqty)." spark plugs<br />";
$totalqty=$tireqty+$oilqty+$sparkqty;
}
$totalamount=$tireqty*TIREPRICE+$oilqty*OILPRICE+$sparkqty*SPARKPRICE;
echo "<p>Total amount is ".number_format($totalamount,2)."</p>";
if($tireqty<10)
$discount=0;
else if($tireqty<=50)
$discount=10;
else if($tireqty<=75)
$discount=30;
else if($tireqty>=100)
$discount=40;


echo "<p>You got a discount of ".$discount." %.</p>";
echo "<p>Address to ship is  ".htmlspecialchars($address)."</p>";
$outputstring=$date."\t".$tireqty." tires\t".$oilqty." oil\t".$sparkqty." spark plugs\t\$".$totalamount."\t".$address."\n";
@$fp=fopen("$documnet_root/doctor/orders.txt","ab");
if(!$fp){
echo "<p><strong>You order could not be processed at this time.<br />
Please try again.</strong></p>";
exit;
}
flock($fp,LOCK_EX);
fwrite($fp,$outputstring,strlen($outputstring));
flock($fp,LOCK_UN);
fclose($fp);
echo "<p>Order Written</p>";
?>
</body>
</html>