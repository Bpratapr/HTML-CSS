<?php require("part3.php");?>
<div class="sink">
<?php
$name=$_POST["name"];
$email=$_POST["email"];
$feedback=$_POST["comment"];
$toaddress=$email;
$mailcontent="Customer name:".$name."\n"."Customer email:".$email."\n"."Customer feedback/comment:\n".$feedback."\n";
$subject="Feedback From Website.";
$fromaddress="From:doctors@gamil.com";
@$set=mail($toaddress,$subject,$mailcontent,$fromaddress);
if(!$set){
	
	echo "<p>Server busy try again later.</p>";
}else{
echo "<p>Feedback Submitted</p>";
echo "<p>Your feedback is as follows:<br />";
echo nl2br(htmlspecialchars($mailcontent))."</p>";
}

?>
</div>
<?php require("part2.php");?>