
<html>
<head>
<link href="logo2.png" type="image/png" rel="shortcut icon" />
<link href="patient.css" type="text/css" rel="stylesheet" />
<style type="text/css">
div.content p{
	text-align:center;
	color:white;
	font-size:30px;
	margin-top:100px;
	
}
div.content p a:link{
	
	color:white;
}

div.content p a:visited{
	
	color:white;
}

div.content p a:hover{
	
	color:red;
}
</style>
</head>
<body>
<div class="header">
<div class="logo">
<img id="logo" src="logo2.png" alt="icon" title="Our Icon" />

</div>
<div class="nav">
<ul>
<li><a class="on" href="profile.php">Profile</a></li>
<li><a class="in" href="patdoc.php">Doctors</a></li>
<li><a class="out" href="details.php">Your Details</a></li>
<li><a class="sin" href="logout.php">Logout</a></li>

</ul>
</div>
</div>

<div class="content">
<?php
session_start();

session_destroy();
echo "<p>You have deen logged out.Go back to <a href='sign.php'>sign in</a> page.</p>";
?>

</div>
<div class="footer">
<p class="foot">&copy; 2017 Your health in your hands</p>
</div>

</body>
</html>